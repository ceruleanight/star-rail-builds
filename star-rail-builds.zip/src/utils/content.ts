import fs from 'fs';
import path from 'path';
import { parsePublicCharacterSlug } from './character-slugs';

export function readJSONFile(filePath: string) {
  const source = fs.readFileSync(filePath, 'utf-8').replace(/^\uFEFF/, '');

  try {
    return JSON.parse(source);
  } catch (error) {
    const parseError = new SyntaxError(
      `${path.relative(process.cwd(), filePath)}: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
    (parseError as SyntaxError & { cause?: unknown }).cause = error;
    throw parseError;
  }
}

/**
 * Returns the localized note for a content item.
 *
 * Supports:
 * - legacy string notes
 * - localized note objects
 *
 * Example:
 * {
 *   note: {
 *     en: "Example note",
 *     fr: "Note d'exemple"
 *   }
 * }
 *
 * Falls back to English if the requested language
 * does not exist.
 *
 * @param item Content item containing a note field.
 * @param lang Current language code.
 * @returns Localized note string or null if no note exists.
 */
export function getLocalizedNote(item: any, lang: string): string | null {
  if (!item?.note) return null;

  if (typeof item.note === 'string') {
    return item.note;
  }

  return item.note[lang] ?? item.note.en ?? null;
}

/**
 * Loads a JSON file from either:
 * - the current build folder
 * - the parent character folder
 *
 * Build-level files override character-level files.
 *
 * Example lookup order:
 * 1. builds/dps/weapons.json
 * 2. character/weapons.json
 *
 * @param buildPath Current build directory path.
 * @param fileName JSON file name.
 * @returns Parsed JSON object or null if the file does not exist.
 */
export function loadJSON(buildPath: string, fileName: string) {
  const buildFile = path.join(buildPath, fileName);
  const charFile = path.join(path.dirname(buildPath), fileName);

  if (fs.existsSync(buildFile)) {
    return readJSONFile(buildFile);
  }

  if (fs.existsSync(charFile)) {
    return readJSONFile(charFile);
  }

  return null;
}

/**
 * Converts a kebab-case string into title case.
 *
 * Example:
 * - "raiden-shogun" -> "Raiden Shogun"
 *
 * @param str Input kebab-case string.
 * @returns Human-readable title string.
 */
export const toTitleCase = (str: string) =>
  str
    .split('-')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

/**
 * Searches the content directory for a character folder.
 *
 * Traverses:
 * - type folders
 * - rarity folders
 *
 * Example structure:
 * content/electro/5-star/raiden-shogun
 *
 * @param base Base content directory.
 * @param char Character slug.
 * @returns Character path information or null if not found.
 */
export function findCharacterPath(
    base: string,
    char: string,
) {
    const lookup =
        parsePublicCharacterSlug(char);

    for (const type of fs.readdirSync(base)) {
        const typePath = path.join(
            base,
            type,
        );

        if (
            !fs.statSync(typePath).isDirectory()
        ) {
            continue;
        }

        for (const rarity of fs.readdirSync(
            typePath,
        )) {
            const rarityPath = path.join(
                typePath,
                rarity,
            );

            if (
                !fs
                    .statSync(rarityPath)
                    .isDirectory()
            ) {
                continue;
            }

            const candidate = path.join(
                rarityPath,
                lookup.character,
            );

            const metadataFile = path.join(
                candidate,
                'metadata.json',
            );

            if (fs.existsSync(metadataFile)) {
                return {
                    type,
                    rarity,
                    path: candidate,
                };
            }
        }
    }

    return null;
}

export function normalizeVersion(version: unknown) {
    return typeof version === 'string'
        ? version
            .trim()
            .replace(/\s*\/\s*/g, ' / ')
            .replace(/\s+/g, ' ')
        : '';
}
